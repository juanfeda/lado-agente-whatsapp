<?php
/**
 * propiedades_api.php — Endpoint de solo lectura para el agente de WhatsApp.
 *
 * Devuelve propiedades ACTIVAS en JSON, con filtros opcionales por query string:
 *   ?operation=venta|alquiler
 *   ?type=casa|departamento|...
 *   ?zone=ENSENADA (busqueda parcial, no exacta)
 *   ?min_price=50000&max_price=120000
 *   ?rooms=3
 *   ?limit=10   (default 10, maximo 30 - para no saturar la respuesta del agente)
 *
 * Protegido con una clave simple por header, para que no sea publico sin mas.
 * Ubicar este archivo en public_html/api/propiedades_api.php (o donde prefieras
 * dentro de public_html), ya que necesita llegar por HTTP.
 */

header('Content-Type: application/json; charset=utf-8');

// ── Seguridad basica: una clave que solo conoce tu agente ──────────────────
// Generá un valor largo y random vos mismo y usalo tambien en ZERNIO... no, en
// LADOWEB_API_KEY del .env del agente. NO la dejes en "cambiame".
define('API_KEY', 'cambiame-por-una-clave-larga-y-random');

$clave_recibida = $_SERVER['HTTP_X_API_KEY'] ?? '';
if (!hash_equals(API_KEY, $clave_recibida)) {
    http_response_code(401);
    echo json_encode(['error' => 'No autorizado']);
    exit;
}

// ── Conexion a la base ──────────────────────────────────────────────────
$RUTA_DB = __DIR__ . '/../includes/lado.db'; // ajustar si este archivo no queda en public_html/api/

try {
    $db = new PDO('sqlite:' . $RUTA_DB);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'No se pudo conectar a la base']);
    exit;
}

// ── Armar la consulta con los filtros recibidos ─────────────────────────
$condiciones = [
    'active = 1',
    // Solo mostrar propiedades realmente disponibles: excluye reservado/alquilado/vendido
    // en cualquier combinacion de mayusculas/minusculas, y las que no tienen estado cargado
    // (estado vacio o NULL) se consideran disponibles.
    "(estado IS NULL OR LOWER(TRIM(estado)) NOT IN ('reservado', 'reservada', 'alquilado', 'alquilada', 'vendido', 'vendida', 'inactiva', 'inactivo'))",
    // Idem para la columna "franja" (VENDIDA / ALQUILADO / RESERVADO en mayuscula, pero
    // se compara sin importar mayus/minus por las dudas).
    "(franja IS NULL OR LOWER(TRIM(franja)) NOT IN ('vendida', 'vendido', 'alquilado', 'alquilada', 'reservado', 'reservada'))",
];
$parametros = [];

if (!empty($_GET['operation'])) {
    $condiciones[] = 'operation = :operation';
    $parametros[':operation'] = strtolower(trim($_GET['operation']));
}
if (!empty($_GET['type'])) {
    $condiciones[] = 'type = :type';
    $parametros[':type'] = strtolower(trim($_GET['type']));
}
if (!empty($_GET['zone'])) {
    $condiciones[] = 'zone LIKE :zone';
    $parametros[':zone'] = '%' . trim($_GET['zone']) . '%';
}
if (!empty($_GET['min_price']) && is_numeric($_GET['min_price'])) {
    $condiciones[] = 'price >= :min_price';
    $parametros[':min_price'] = (float) $_GET['min_price'];
}
if (!empty($_GET['max_price']) && is_numeric($_GET['max_price'])) {
    $condiciones[] = 'price <= :max_price';
    $parametros[':max_price'] = (float) $_GET['max_price'];
}
if (!empty($_GET['rooms']) && is_numeric($_GET['rooms'])) {
    $condiciones[] = 'rooms >= :rooms';
    $parametros[':rooms'] = (int) $_GET['rooms'];
}

$limit = 10;
if (!empty($_GET['limit']) && is_numeric($_GET['limit'])) {
    $limit = max(1, min(30, (int) $_GET['limit']));
}

$where = implode(' AND ', $condiciones);

$sql = "SELECT id, title, description, operation, type, price, currency, zone,
               address, m2, rooms, bedrooms, bathrooms, garage, apta_banco
        FROM properties
        WHERE $where
        ORDER BY featured DESC, updated_at DESC
        LIMIT $limit";

$stmt = $db->prepare($sql);
$stmt->execute($parametros);
$propiedades = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Traer la primera imagen de cada propiedad, para que el agente pueda mandarla
foreach ($propiedades as &$p) {
    $img = $db->prepare('SELECT url FROM images WHERE property_id = :id ORDER BY sort_order ASC LIMIT 1');
    $img->execute([':id' => $p['id']]);
    $url = $img->fetchColumn();
    $p['imagen'] = $url ? ('https://www.ladoinmobiliaria.com.ar/' . ltrim($url, '/')) : null;
    $p['url'] = 'https://www.ladoinmobiliaria.com.ar/propiedad.php?id=' . $p['id'];
}
unset($p);

echo json_encode(['propiedades' => $propiedades, 'total' => count($propiedades)], JSON_UNESCAPED_UNICODE);
